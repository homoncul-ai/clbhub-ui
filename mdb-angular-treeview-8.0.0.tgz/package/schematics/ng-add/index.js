"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ngAdd = ngAdd;
const tasks_1 = require("@angular-devkit/schematics/tasks");
// Just return the tree
function ngAdd(options) {
    return (_, context) => {
        context.addTask(new tasks_1.RunSchematicTask('ng-add-treeview-setup', options));
    };
}
//# sourceMappingURL=index.js.map