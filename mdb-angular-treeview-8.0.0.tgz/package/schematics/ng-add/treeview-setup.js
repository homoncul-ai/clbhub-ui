"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const workspace_models_1 = require("@schematics/angular/utility/workspace-models");
const schematics_2 = require("@angular/cdk/schematics");
// eslint-disable-next-line space-before-function-paren
function default_1(options) {
    return (tree) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, workspace_1.getWorkspace)(tree);
        const project = (0, schematics_2.getProjectFromWorkspace)(workspace, options.project);
        if (project.extensions.projectType === workspace_models_1.ProjectType.Application) {
            return (0, schematics_1.chain)([addMdbModulesImports(options), addStylesImports(options)]);
        }
        return;
    });
}
function addMdbModulesImports(options) {
    return (tree) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, workspace_1.getWorkspace)(tree);
        const project = (0, schematics_2.getProjectFromWorkspace)(workspace, options.project);
        const module = { name: 'MdbTreeviewModule', path: 'mdb-angular-treeview' };
        const mainFile = (0, schematics_2.getProjectMainFile)(project);
        if ((0, schematics_2.isStandaloneApp)(tree, mainFile)) {
            return;
        }
        (0, schematics_2.addModuleImportToRootModule)(tree, module.name, module.path, project);
        return tree;
    });
}
function addStylesImports(options) {
    return (host, context) => __awaiter(this, void 0, void 0, function* () {
        const workspace = yield (0, workspace_1.getWorkspace)(host);
        const project = (0, schematics_2.getProjectFromWorkspace)(workspace, options.project);
        const logger = context.logger;
        const styleFilePath = (0, schematics_2.getProjectStyleFile)(project);
        if (!styleFilePath) {
            logger.error(`Could not find the default style file for this project. Please add styles imports manually`);
            return;
        }
        const buffer = host.read(styleFilePath);
        if (!buffer) {
            logger.error(`Could not read the default style file for this project. Please add styles imports manually`);
            return;
        }
        const fileContent = buffer.toString();
        const newContent = `@import 'mdb-angular-treeview/scss/treeview.scss';\n`;
        if (fileContent.includes(newContent)) {
            return;
        }
        const recorder = host.beginUpdate(styleFilePath);
        recorder.insertLeft(fileContent.length, newContent);
        host.commitUpdate(recorder);
    });
}
//# sourceMappingURL=treeview-setup.js.map