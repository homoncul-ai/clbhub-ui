import * as i0 from "@angular/core";
import * as i1 from "./treeview.component";
import * as i2 from "./treeview-item.component";
import * as i3 from "@angular/common";
import * as i4 from "mdb-angular-ui-kit/checkbox";
import * as i5 from "mdb-angular-ui-kit/collapse";
export declare class MdbTreeviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTreeviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbTreeviewModule, [typeof i1.MdbTreeviewComponent, typeof i2.MdbTreeviewItemComponent], [typeof i3.CommonModule, typeof i4.MdbCheckboxModule, typeof i5.MdbCollapseModule], [typeof i1.MdbTreeviewComponent, typeof i2.MdbTreeviewItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbTreeviewModule>;
}
