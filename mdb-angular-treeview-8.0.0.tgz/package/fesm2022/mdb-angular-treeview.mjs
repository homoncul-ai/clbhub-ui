import * as i0 from '@angular/core';
import { InjectionToken, booleanAttribute, numberAttribute, HostListener, HostBinding, Input, ViewChild, ViewChildren, Optional, SkipSelf, Inject, ChangeDetectionStrategy, Component, EventEmitter, Output, NgModule } from '@angular/core';
import * as i3 from 'mdb-angular-ui-kit/collapse';
import { MdbCollapseDirective, MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import * as i2 from 'mdb-angular-ui-kit/checkbox';
import { MdbCheckboxDirective, MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

const MDB_TREEVIEW_PARENT = new InjectionToken('MDB_TREEVIEW_PARENT');
class MdbTreeviewItemComponent {
    cdRef;
    elRef;
    parentItem;
    treeview;
    anchor;
    checkbox;
    children;
    collapse;
    accordion = false;
    checkedField = 'checked';
    childrenField = 'children';
    line = false;
    node;
    openOnClick = true;
    rotationAngle = 90;
    selectable = false;
    textField = 'name';
    get levelAttribute() {
        return this.node.level + 1;
    }
    roleItemAttribute = 'tree-item';
    tabindexAttribute = -1;
    get activeClass() {
        return !this.hasChildren && this.active;
    }
    get treeviewCategoryClass() {
        return !this.hasChildren;
    }
    get treeviewDisabledClass() {
        return !this.hasChildren && this.node.disabled;
    }
    treeviewItemClass = true;
    _onHostClick(event) {
        if (!this.hasChildren) {
            this._onClick(event);
        }
    }
    get collapseIconClass() {
        return this.node.collapseIcon || 'fas fa-angle-right';
    }
    get hasChildren() {
        return this.node[this.childrenField]?.length > 0;
    }
    get rotationStyle() {
        const isCollapsed = this.collapse ? this.collapse.collapsed : this.node.collapsed;
        const angle = isCollapsed ? 0 : this.rotationAngle;
        return {
            transform: `rotate(${angle}deg)`,
        };
    }
    active = false;
    constructor(cdRef, elRef, parentItem, treeview) {
        this.cdRef = cdRef;
        this.elRef = elRef;
        this.parentItem = parentItem;
        this.treeview = treeview;
    }
    ngOnInit() {
        this.treeview._registerItem(this);
    }
    _onCheckboxChange() {
        this.treeview.selected.emit(this.node);
    }
    _onClick(event) {
        this.treeview._setActiveItem(this);
        this.treeview._setFocusedItem(this);
        const eventTarget = event.target;
        if (this.collapse) {
            const isNotCheckbox = !(eventTarget instanceof HTMLInputElement && eventTarget.type === 'checkbox');
            const isToggle = eventTarget.closest('span[aria-label="toggle"]') != null;
            const shouldToggle = (this.openOnClick || isToggle) && isNotCheckbox;
            if (shouldToggle) {
                this.collapse.toggle();
            }
        }
    }
    _onCollapseHide() {
        this._collapseChildren();
    }
    _onCollapseShow() {
        if (this.accordion) {
            const siblings = this.parentItem?.children?.toArray();
            if (siblings?.length) {
                siblings.forEach((sibling) => sibling.collapse?.hide());
            }
        }
    }
    _onCheckboxClick() {
        this._propagateChangeToChildren(this, this.checkbox.checked);
        this._updateParentNodeState();
    }
    _collapseChildren() {
        const children = this.children.toArray();
        if (children.length) {
            children.forEach((child) => {
                child.collapse?.hide();
                child._collapseChildren();
            });
        }
    }
    _propagateChangeToChildren(parent, state) {
        const children = parent.children.toArray();
        const notDisabledChildren = children.filter((child) => !child.node.disabled);
        if (notDisabledChildren.length) {
            notDisabledChildren.forEach((child) => {
                child.checkbox.checked = state;
                child.cdRef.markForCheck();
                if (child.hasChildren) {
                    this._propagateChangeToChildren(child, state);
                }
            });
        }
    }
    _updateParentNodeState() {
        if (this.parentItem && !this.parentItem.node.disabled) {
            const siblings = this.parentItem.children.toArray();
            const allSiblingsChecked = siblings.every((sibling) => sibling.checkbox.checked);
            this.parentItem.checkbox.checked = allSiblingsChecked;
            this.parentItem._updateParentNodeState();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewItemComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: MdbTreeviewItemComponent, optional: true, skipSelf: true }, { token: MDB_TREEVIEW_PARENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbTreeviewItemComponent, isStandalone: false, selector: "mdb-treeview-item", inputs: { accordion: ["accordion", "accordion", booleanAttribute], checkedField: "checkedField", childrenField: "childrenField", line: ["line", "line", booleanAttribute], node: "node", openOnClick: ["openOnClick", "openOnClick", booleanAttribute], rotationAngle: ["rotationAngle", "rotationAngle", numberAttribute], selectable: ["selectable", "selectable", booleanAttribute], textField: "textField" }, host: { listeners: { "click": "_onHostClick($event)" }, properties: { "attr.level": "this.levelAttribute", "attr.role": "this.roleItemAttribute", "attr.tabindex": "this.tabindexAttribute", "class.active": "this.activeClass", "class.treeview-category": "this.treeviewCategoryClass", "class.treeview-disabled": "this.treeviewDisabledClass", "class.treeview-item": "this.treeviewItemClass" } }, viewQueries: [{ propertyName: "anchor", first: true, predicate: ["anchor"], descendants: true }, { propertyName: "checkbox", first: true, predicate: MdbCheckboxDirective, descendants: true }, { propertyName: "collapse", first: true, predicate: MdbCollapseDirective, descendants: true }, { propertyName: "children", predicate: ["childItem"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"!hasChildren\">\n  <ng-container *ngIf=\"selectable\" [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n  <i *ngIf=\"node.icon\" [ngClass]=\"node.icon\"></i>\n  {{ node[textField] }}\n</ng-container>\n\n<ng-container *ngIf=\"hasChildren\">\n  <a\n    #anchor\n    class=\"treeview-category\"\n    role=\"button\"\n    tabindex=\"-1\"\n    [attr.aria-expanded]=\"!node.collapsed\"\n    [ngClass]=\"{ 'treeview-disabled': node.disabled, active: active }\"\n    [ngStyle]=\"{ 'margin-left.rem': selectable ? -1 : 0 }\"\n    (click)=\"_onClick($event)\"\n  >\n    <span aria-label=\"toggle\">\n      <i class=\"mx-1\" [ngClass]=\"collapseIconClass\" [ngStyle]=\"rotationStyle\"></i\n    ></span>\n    <ng-container *ngIf=\"selectable\" [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n    <i *ngIf=\"node.icon\" [ngClass]=\"node.icon\"></i>\n    {{ node[treeview.textField] }}</a\n  >\n  <ul\n    role=\"tree\"\n    [ngClass]=\"{ 'treeview-line': line }\"\n    mdbCollapse\n    [collapsed]=\"node.collapsed\"\n    (collapseShow)=\"_onCollapseShow()\"\n    (collapseHide)=\"_onCollapseHide()\"\n  >\n    <mdb-treeview-item\n      #childItem\n      *ngFor=\"let childNode of node[childrenField]\"\n      [accordion]=\"accordion\"\n      [checkedField]=\"checkedField\"\n      [childrenField]=\"childrenField\"\n      [line]=\"line\"\n      [node]=\"childNode\"\n      [openOnClick]=\"openOnClick\"\n      [rotationAngle]=\"rotationAngle\"\n      [selectable]=\"selectable\"\n      [textField]=\"textField\"\n    ></mdb-treeview-item>\n  </ul>\n</ng-container>\n\n<ng-template #checkboxTemplate>\n  <input\n    mdbCheckbox\n    class=\"form-check-input mx-1\"\n    type=\"checkbox\"\n    value=\"\"\n    [disabled]=\"node.disabled\"\n    (click)=\"_onCheckboxClick()\"\n    [checked]=\"node[checkedField]\"\n    (change)=\"_onCheckboxChange()\"\n  />\n</ng-template>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.MdbCheckboxDirective, selector: "[mdbCheckbox]", inputs: ["checked", "value", "disabled"], outputs: ["checkboxChange"] }, { kind: "directive", type: i3.MdbCollapseDirective, selector: "[mdbCollapse]", inputs: ["collapsed"], outputs: ["collapseShow", "collapseShown", "collapseHide", "collapseHidden"], exportAs: ["mdbCollapse"] }, { kind: "component", type: MdbTreeviewItemComponent, selector: "mdb-treeview-item", inputs: ["accordion", "checkedField", "childrenField", "line", "node", "openOnClick", "rotationAngle", "selectable", "textField"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-treeview-item', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<ng-container *ngIf=\"!hasChildren\">\n  <ng-container *ngIf=\"selectable\" [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n  <i *ngIf=\"node.icon\" [ngClass]=\"node.icon\"></i>\n  {{ node[textField] }}\n</ng-container>\n\n<ng-container *ngIf=\"hasChildren\">\n  <a\n    #anchor\n    class=\"treeview-category\"\n    role=\"button\"\n    tabindex=\"-1\"\n    [attr.aria-expanded]=\"!node.collapsed\"\n    [ngClass]=\"{ 'treeview-disabled': node.disabled, active: active }\"\n    [ngStyle]=\"{ 'margin-left.rem': selectable ? -1 : 0 }\"\n    (click)=\"_onClick($event)\"\n  >\n    <span aria-label=\"toggle\">\n      <i class=\"mx-1\" [ngClass]=\"collapseIconClass\" [ngStyle]=\"rotationStyle\"></i\n    ></span>\n    <ng-container *ngIf=\"selectable\" [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n    <i *ngIf=\"node.icon\" [ngClass]=\"node.icon\"></i>\n    {{ node[treeview.textField] }}</a\n  >\n  <ul\n    role=\"tree\"\n    [ngClass]=\"{ 'treeview-line': line }\"\n    mdbCollapse\n    [collapsed]=\"node.collapsed\"\n    (collapseShow)=\"_onCollapseShow()\"\n    (collapseHide)=\"_onCollapseHide()\"\n  >\n    <mdb-treeview-item\n      #childItem\n      *ngFor=\"let childNode of node[childrenField]\"\n      [accordion]=\"accordion\"\n      [checkedField]=\"checkedField\"\n      [childrenField]=\"childrenField\"\n      [line]=\"line\"\n      [node]=\"childNode\"\n      [openOnClick]=\"openOnClick\"\n      [rotationAngle]=\"rotationAngle\"\n      [selectable]=\"selectable\"\n      [textField]=\"textField\"\n    ></mdb-treeview-item>\n  </ul>\n</ng-container>\n\n<ng-template #checkboxTemplate>\n  <input\n    mdbCheckbox\n    class=\"form-check-input mx-1\"\n    type=\"checkbox\"\n    value=\"\"\n    [disabled]=\"node.disabled\"\n    (click)=\"_onCheckboxClick()\"\n    [checked]=\"node[checkedField]\"\n    (change)=\"_onCheckboxChange()\"\n  />\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: MdbTreeviewItemComponent, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MDB_TREEVIEW_PARENT]
                }] }], propDecorators: { anchor: [{
                type: ViewChild,
                args: ['anchor']
            }], checkbox: [{
                type: ViewChild,
                args: [MdbCheckboxDirective]
            }], children: [{
                type: ViewChildren,
                args: ['childItem']
            }], collapse: [{
                type: ViewChild,
                args: [MdbCollapseDirective]
            }], accordion: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], checkedField: [{
                type: Input
            }], childrenField: [{
                type: Input
            }], line: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], node: [{
                type: Input,
                args: [{ required: true }]
            }], openOnClick: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], rotationAngle: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], selectable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], textField: [{
                type: Input
            }], levelAttribute: [{
                type: HostBinding,
                args: ['attr.level']
            }], roleItemAttribute: [{
                type: HostBinding,
                args: ['attr.role']
            }], tabindexAttribute: [{
                type: HostBinding,
                args: ['attr.tabindex']
            }], activeClass: [{
                type: HostBinding,
                args: ['class.active']
            }], treeviewCategoryClass: [{
                type: HostBinding,
                args: ['class.treeview-category']
            }], treeviewDisabledClass: [{
                type: HostBinding,
                args: ['class.treeview-disabled']
            }], treeviewItemClass: [{
                type: HostBinding,
                args: ['class.treeview-item']
            }], _onHostClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class MdbTreeviewComponent {
    _cdRef;
    accordion = false;
    checkedField = 'checked';
    childrenField = 'children';
    color = 'primary';
    line = false;
    get nodes() {
        return this._nodes;
    }
    set nodes(newData) {
        this._nodes = newData;
        if (this._isLoaded) {
            this._updateData(newData);
            this._cdRef.markForCheck();
        }
    }
    _nodes;
    openOnClick = true;
    rotationAngle = 90;
    selectable = false;
    textField = 'name';
    selected = new EventEmitter();
    activeItemChange = new EventEmitter();
    tabindexAttribute = 0;
    treeviewClass = true;
    get colorClass() {
        return `treeview-${this.color}`;
    }
    _onKeydown(event) {
        const { key } = event;
        const isSpace = key === ' ';
        const isTab = key === 'Tab';
        if (!isSpace && !isTab) {
            event.stopPropagation();
            event.preventDefault();
        }
        switch (key) {
            case 'ArrowDown':
                this._onKeydownArrowDown();
                break;
            case 'ArrowLeft':
                this._onKeydownArrowLeft();
                break;
            case 'ArrowRight':
                this._onKeydownArrowRight();
                break;
            case 'ArrowUp':
                this._onKeydownArrowUp();
                break;
            case 'End':
                this._onKeydownEnd();
                break;
            case 'Enter':
                this._onKeydownEnter();
                break;
            case 'Home':
                this._onKeydownHome();
                break;
        }
    }
    _activeItem = null;
    _focusedItem = null;
    _isLoaded = false;
    data = [];
    items = [];
    constructor(_cdRef) {
        this._cdRef = _cdRef;
    }
    ngOnInit() {
        this._updateData(this.nodes);
        this._isLoaded = true;
    }
    collapse() {
        this.items.forEach((item) => {
            if (item.collapse) {
                item.collapse.hide();
                item.cdRef.markForCheck();
            }
        });
    }
    expand(id) {
        const expandItem = this.items.find((item) => item.node.expandId === id);
        if (expandItem) {
            this._expandWithParents(expandItem);
        }
    }
    filter(value) {
        this.collapse();
        for (let item of this.items) {
            const includes = item.node[this.textField]
                .toLowerCase()
                .trim()
                .includes(value.toLowerCase().trim());
            if (includes) {
                this._expandWithParents(item);
                break;
            }
        }
    }
    _registerItem(item) {
        this.items.push(item);
    }
    _setActiveItem(item) {
        if (item.node.disabled) {
            return;
        }
        if (this._activeItem && this._activeItem !== item) {
            this._activeItem.active = false;
            this._activeItem.cdRef.markForCheck();
        }
        item.active = true;
        item.cdRef.markForCheck();
        const elementToEmit = item.anchor ? item.anchor : item.elRef;
        this.activeItemChange.emit(elementToEmit);
        this._activeItem = item;
    }
    _setFocusedItem(item) {
        this._focusedItem = item;
    }
    _expandWithParents(item) {
        const itemsToExpand = new Set();
        const addToList = (item) => {
            if (item.collapse) {
                itemsToExpand.add(item);
            }
            const isParentCollapsed = item.parentItem?.collapse.collapsed;
            if (isParentCollapsed) {
                itemsToExpand.add(item.parentItem);
                addToList(item.parentItem);
            }
        };
        const expandItems = (items) => {
            items.forEach((item) => {
                item.collapse.show();
            });
        };
        addToList(item);
        expandItems(itemsToExpand);
    }
    _focusProperTarget(item) {
        item.collapse ? item.anchor.nativeElement.focus() : item.elRef.nativeElement.focus();
        this._setFocusedItem(item);
    }
    _getFocusableItems() {
        let focusableItems = [];
        for (let item of this.items) {
            if (item.parentItem?.collapse.collapsed) {
                continue;
            }
            focusableItems.push(item);
        }
        return focusableItems;
    }
    _onKeydownArrowDown() {
        const focusableItems = this._getFocusableItems();
        if (this._focusedItem === null) {
            const [firstItem] = this.items;
            this._focusProperTarget(firstItem);
            return;
        }
        const currentItemIndex = focusableItems.indexOf(this._focusedItem);
        const nextItem = focusableItems[currentItemIndex + 1];
        if (nextItem) {
            this._focusProperTarget(nextItem);
        }
    }
    _onKeydownArrowLeft() {
        this._focusedItem.collapse?.hide();
    }
    _onKeydownArrowRight() {
        this._focusedItem.collapse?.show();
    }
    _onKeydownArrowUp() {
        const focusableItems = this._getFocusableItems();
        const currentItemIndex = focusableItems.indexOf(this._focusedItem);
        const previousItem = focusableItems[currentItemIndex - 1];
        if (previousItem) {
            this._focusProperTarget(previousItem);
        }
    }
    _onKeydownEnd() {
        const focusableItems = this._getFocusableItems();
        const lastItem = focusableItems[focusableItems.length - 1];
        this._focusProperTarget(lastItem);
    }
    _onKeydownEnter() {
        this._setActiveItem(this._focusedItem);
    }
    _onKeydownHome() {
        const [firstItem] = this.items;
        this._focusProperTarget(firstItem);
    }
    _updateData(data, level = 0, parentChecked = false, parentCollapsed = false, parentDisabled = false) {
        const isNodeChecked = (node, parentChecked) => {
            return (parentChecked || node[this.checkedField] === true || node[this.checkedField] === 'true');
        };
        const isNodeCollapsed = (node, parentCollapsed) => {
            const hasChildren = node[this.childrenField] && node[this.childrenField].length > 0;
            if (hasChildren) {
                const nodeIsCollapsed = node.collapsed === true || node.collapsed === 'true' || node.collapsed === 'True';
                const nodeIsExpanded = node.collapsed === false || node.collapsed === 'false' || node.collapsed === 'False';
                // If the parent is collapsed, all children are forced to collapse
                if (parentCollapsed) {
                    return true; // Parent is collapsed, so collapse all descendants
                }
                // If the node explicitly says 'collapsed: true', collapse it
                else if (nodeIsCollapsed) {
                    return true;
                }
                // If the node explicitly says 'collapsed: false', expand it
                else if (nodeIsExpanded) {
                    return false;
                }
                // If no collapsed property is set, default to collapsed
                else {
                    return true; // Default to collapsed when no property is specified
                }
            }
            // If the node has no children, collapsed state doesn't apply
            return undefined;
        };
        const isNodeDisabled = (node, parentDisabled) => {
            return parentDisabled || node.disabled === true || node.disabled === 'true';
        };
        const updateChildrenNodes = (node, level, checked, collapsed, disabled) => {
            return this._updateData(node[this.childrenField], level + 1, checked, collapsed, disabled);
        };
        const updatedData = data.map((node) => {
            node.level = level;
            if (this.selectable) {
                node[this.checkedField] = isNodeChecked(node, parentChecked);
            }
            node.collapsed = isNodeCollapsed(node, parentCollapsed);
            node.disabled = isNodeDisabled(node, parentDisabled);
            // Recursively update children if they exist
            if (node[this.childrenField] && node[this.childrenField].length > 0) {
                node[this.childrenField] = updateChildrenNodes(node, level, node[this.checkedField], node.collapsed, node.disabled);
            }
            return node;
        });
        // Because of the recursive nature of this function we want to update data just once at level 0
        // to avoid redundant updates at deeper levels
        if (level === 0) {
            this.data = updatedData;
        }
        return updatedData;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbTreeviewComponent, isStandalone: false, selector: "mdb-treeview", inputs: { accordion: ["accordion", "accordion", booleanAttribute], checkedField: "checkedField", childrenField: "childrenField", color: "color", line: ["line", "line", booleanAttribute], nodes: "nodes", openOnClick: ["openOnClick", "openOnClick", booleanAttribute], rotationAngle: ["rotationAngle", "rotationAngle", numberAttribute], selectable: ["selectable", "selectable", booleanAttribute], textField: "textField" }, outputs: { selected: "selected", activeItemChange: "activeItemChange" }, host: { listeners: { "keydown": "_onKeydown($event)" }, properties: { "attr.tabindex": "this.tabindexAttribute", "class.treeview": "this.treeviewClass", "class": "this.colorClass" } }, providers: [{ provide: MDB_TREEVIEW_PARENT, useExisting: MdbTreeviewComponent }], exportAs: ["mdbTreeview"], ngImport: i0, template: "<ul role=\"tree\">\n  <mdb-treeview-item\n    *ngFor=\"let node of data\"\n    [accordion]=\"accordion\"\n    [checkedField]=\"checkedField\"\n    [childrenField]=\"childrenField\"\n    [line]=\"line\"\n    [node]=\"node\"\n    [openOnClick]=\"openOnClick\"\n    [rotationAngle]=\"rotationAngle\"\n    [selectable]=\"selectable\"\n    [textField]=\"textField\"\n  ></mdb-treeview-item>\n</ul>\n", dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: MdbTreeviewItemComponent, selector: "mdb-treeview-item", inputs: ["accordion", "checkedField", "childrenField", "line", "node", "openOnClick", "rotationAngle", "selectable", "textField"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-treeview', exportAs: 'mdbTreeview', changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: MDB_TREEVIEW_PARENT, useExisting: MdbTreeviewComponent }], standalone: false, template: "<ul role=\"tree\">\n  <mdb-treeview-item\n    *ngFor=\"let node of data\"\n    [accordion]=\"accordion\"\n    [checkedField]=\"checkedField\"\n    [childrenField]=\"childrenField\"\n    [line]=\"line\"\n    [node]=\"node\"\n    [openOnClick]=\"openOnClick\"\n    [rotationAngle]=\"rotationAngle\"\n    [selectable]=\"selectable\"\n    [textField]=\"textField\"\n  ></mdb-treeview-item>\n</ul>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { accordion: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], checkedField: [{
                type: Input
            }], childrenField: [{
                type: Input
            }], color: [{
                type: Input
            }], line: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], nodes: [{
                type: Input
            }], openOnClick: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], rotationAngle: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], selectable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], textField: [{
                type: Input
            }], selected: [{
                type: Output
            }], activeItemChange: [{
                type: Output
            }], tabindexAttribute: [{
                type: HostBinding,
                args: ['attr.tabindex']
            }], treeviewClass: [{
                type: HostBinding,
                args: ['class.treeview']
            }], colorClass: [{
                type: HostBinding,
                args: ['class']
            }], _onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

class MdbTreeviewModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewModule, declarations: [MdbTreeviewComponent, MdbTreeviewItemComponent], imports: [CommonModule, MdbCheckboxModule, MdbCollapseModule], exports: [MdbTreeviewComponent, MdbTreeviewItemComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewModule, imports: [CommonModule, MdbCheckboxModule, MdbCollapseModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTreeviewModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MdbTreeviewComponent, MdbTreeviewItemComponent],
                    imports: [CommonModule, MdbCheckboxModule, MdbCollapseModule],
                    exports: [MdbTreeviewComponent, MdbTreeviewItemComponent],
                }]
        }] });

/*
 * Public API Surface of mdb-angular-treeview
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MDB_TREEVIEW_PARENT, MdbTreeviewComponent, MdbTreeviewItemComponent, MdbTreeviewModule };
//# sourceMappingURL=mdb-angular-treeview.mjs.map
