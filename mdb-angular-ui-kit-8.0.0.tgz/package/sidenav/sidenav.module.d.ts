import * as i0 from "@angular/core";
import * as i1 from "./sidenav.component";
import * as i2 from "./sidenav-layout.component";
import * as i3 from "./sidenav-content.component";
import * as i4 from "./sidenav-item.component";
import * as i5 from "./sidenav-menu.directive";
import * as i6 from "@angular/common";
import * as i7 from "mdb-angular-ui-kit/collapse";
import * as i8 from "mdb-angular-ui-kit/scrollbar";
export declare class MdbSidenavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbSidenavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbSidenavModule, [typeof i1.MdbSidenavComponent, typeof i2.MdbSidenavLayoutComponent, typeof i3.MdbSidenavContentComponent, typeof i4.MdbSidenavItemComponent, typeof i5.MdbSidenavMenuDirective], [typeof i6.CommonModule, typeof i7.MdbCollapseModule, typeof i8.MdbScrollbarModule], [typeof i1.MdbSidenavComponent, typeof i2.MdbSidenavLayoutComponent, typeof i3.MdbSidenavContentComponent, typeof i4.MdbSidenavItemComponent, typeof i5.MdbSidenavMenuDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbSidenavModule>;
}
