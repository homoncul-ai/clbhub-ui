import { AfterViewInit, EventEmitter, QueryList, OnDestroy, AfterContentInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MdbRatingIconComponent } from './rating-icon.component';
import * as i0 from "@angular/core";
export declare class MdbRatingComponent implements AfterContentInit, AfterViewInit, OnDestroy {
    icons: QueryList<MdbRatingIconComponent>;
    readonly: boolean;
    get value(): number;
    set value(newValue: number);
    private _value;
    onSelect: EventEmitter<number>;
    onHover: EventEmitter<number>;
    private _iconIndex;
    private _icon;
    private _selectedIcon;
    readonly _destroy$: Subject<void>;
    constructor();
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    setActive(iconIndex: number, iconClass?: string): void;
    onClick(): void;
    onMouseleave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRatingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbRatingComponent, "mdb-rating", never, { "readonly": { "alias": "readonly"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "onSelect": "onSelect"; "onHover": "onHover"; }, ["icons"], ["*"], false, never>;
}
