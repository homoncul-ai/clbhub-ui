export { MdbMultiRangeComponent } from './multi-range.component';
export { MdbMultiRangeThumbDirective } from './multi-range-thumb.directive';
export { MdbMultiRangeModule } from './multi-range.module';
