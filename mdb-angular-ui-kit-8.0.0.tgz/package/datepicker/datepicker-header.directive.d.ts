import { InjectionToken, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare const MDB_DATEPICKER_HEADER: InjectionToken<MdbDatepickerHeaderDirective>;
export declare class MdbDatepickerHeaderDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDatepickerHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbDatepickerHeaderDirective, "[mdbDatepickerHeader]", never, {}, {}, never, never, false, never>;
}
