import { OnInit, ElementRef, TemplateRef, ViewContainerRef, AfterContentInit } from '@angular/core';
import { MdbDatepickerComponent } from './datepicker.component';
import { TemplatePortal } from '@angular/cdk/portal';
import { BooleanInput } from '@angular/cdk/coercion';
import * as i0 from "@angular/core";
export declare class MdbDatepickerToggleComponent implements OnInit, AfterContentInit {
    private _vcr;
    button: ElementRef<HTMLElement>;
    _iconRef: TemplateRef<any>;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    icon: string;
    mdbDatepicker: MdbDatepickerComponent;
    get iconRef(): TemplatePortal | null;
    private _iconPortal;
    constructor(_vcr: ViewContainerRef);
    onClick(): void;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    open(): void;
    close(): void;
    toggle(): void;
    private _createIconPortal;
    static ngAcceptInputType_disabled: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDatepickerToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbDatepickerToggleComponent, "mdb-datepicker-toggle", never, { "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "mdbDatepicker": { "alias": "mdbDatepicker"; "required": false; }; }, {}, ["_iconRef"], never, false, never>;
}
