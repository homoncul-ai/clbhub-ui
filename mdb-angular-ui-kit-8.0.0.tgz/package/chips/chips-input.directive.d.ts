import { ChangeDetectorRef, ElementRef, EventEmitter } from '@angular/core';
import { MdbAbstractFormControl } from 'mdb-angular-ui-kit/forms';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export interface MdbChipAddEvent {
    value: string;
    input: MdbChipsInputDirective;
}
export declare class MdbChipsInputDirective implements MdbAbstractFormControl<any> {
    private _elementRef;
    _cdRef: ChangeDetectorRef;
    chipAdd: EventEmitter<MdbChipAddEvent>;
    onKeydown(event: KeyboardEvent): void;
    onFocusOut(): void;
    get input(): HTMLInputElement;
    get hasValue(): boolean;
    get labelActive(): boolean;
    readonly stateChanges: Subject<void>;
    readonly deleteChip: Subject<void>;
    private _confirmKeys;
    private _removeKeys;
    _hasItems: boolean;
    constructor(_elementRef: ElementRef, _cdRef: ChangeDetectorRef);
    private _isConfirmKey;
    private _isDeleteKey;
    private _emitChipAddEvent;
    clear(): void;
    _updateLabelState(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbChipsInputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbChipsInputDirective, "[mdbChipsInput]", never, {}, { "chipAdd": "chipAdd"; }, never, never, false, never>;
}
