import * as i0 from "@angular/core";
import * as i1 from "./chips-input.directive";
import * as i2 from "./chips.component";
import * as i3 from "./chip.component";
import * as i4 from "./chip-delete.directive";
import * as i5 from "@angular/common";
export declare class MdbChipsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbChipsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbChipsModule, [typeof i1.MdbChipsInputDirective, typeof i2.MdbChipsComponent, typeof i3.MdbChipComponent, typeof i4.MdbChipDeleteDirective], [typeof i5.CommonModule], [typeof i1.MdbChipsInputDirective, typeof i2.MdbChipsComponent, typeof i3.MdbChipComponent, typeof i4.MdbChipDeleteDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbChipsModule>;
}
