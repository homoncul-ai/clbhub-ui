import { AfterContentInit, ElementRef, OnDestroy, QueryList } from '@angular/core';
import { MdbChipComponent } from './chip.component';
import { MdbChipsInputDirective } from './chips-input.directive';
import * as i0 from "@angular/core";
export declare class MdbChipsComponent implements AfterContentInit, OnDestroy {
    chipsInput: MdbChipsInputDirective;
    inputEl: ElementRef;
    chips: QueryList<MdbChipComponent>;
    private _destroy$;
    chipsClass: boolean;
    chipsInitial: boolean;
    onFocus(event: any): void;
    constructor();
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbChipsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbChipsComponent, "mdb-chips", never, {}, {}, ["chipsInput", "inputEl", "chips"], ["*"], false, never>;
}
