import { ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export type MdbDropdownMenuPositionClass = 'dropdown-menu-end';
export declare class MdbDropdownMenuDirective {
    elementRef: ElementRef;
    private _renderer;
    constructor(elementRef: ElementRef, _renderer: Renderer2);
    menuPositionClassChanged: EventEmitter<string>;
    get menuPositionClass(): string;
    set menuPositionClass(newClass: string);
    private _menuPositionClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDropdownMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbDropdownMenuDirective, "[mdbDropdownMenu]", ["mdbDropdownMenu"], { "menuPositionClass": { "alias": "menuPositionClass"; "required": false; }; }, { "menuPositionClassChanged": "menuPositionClassChanged"; }, never, never, false, never>;
}
