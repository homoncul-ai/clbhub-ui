import * as i0 from '@angular/core';
import { InjectionToken, EventEmitter, numberAttribute, Output, Input, Inject, Directive, forwardRef, booleanAttribute, ViewChildren, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import * as i1 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { Subject, fromEvent, merge, first } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { trigger, transition, useAnimation, animation, animate, keyframes, style } from '@angular/animations';

const MDB_MULTI_RANGE = new InjectionToken('MDB_MULTI_RANGE');
class MdbMultiRangeThumbDirective {
    _elementRef;
    _document;
    _ngZone;
    _cdRef;
    _multiRange;
    startValue = 0;
    get host() {
        return this._elementRef.nativeElement;
    }
    coordinates = { initialX: 0, currentX: 0 };
    showTooltip = false;
    _maxPosition;
    _minPosition;
    _numberOfAvailableValues = 0;
    _sliderEl;
    _sliderWidth = 0;
    _destroy$ = new Subject();
    THUMB_WIDTH = 16;
    startDrag = new EventEmitter();
    changeValue = new EventEmitter();
    pointerMove = new EventEmitter();
    constructor(_elementRef, _document, _ngZone, _cdRef, _multiRange) {
        this._elementRef = _elementRef;
        this._document = _document;
        this._ngZone = _ngZone;
        this._cdRef = _cdRef;
        this._multiRange = _multiRange;
    }
    ngOnInit() {
        this._initValues();
        this._updatePosition(this.startValue);
        this._initDrag();
        if (typeof window !== 'undefined') {
            fromEvent(window, 'resize')
                .pipe(takeUntil(this._destroy$))
                .subscribe(() => {
                this._ngZone.runOutsideAngular(() => {
                    const newSliderWidth = this._sliderEl.offsetWidth - this.THUMB_WIDTH;
                    const scale = this._sliderWidth / newSliderWidth;
                    this.coordinates.currentX = this.coordinates.currentX / scale;
                    this._sliderWidth = newSliderWidth;
                    this.host.style.left = `${this._getOffsetLeft()}px`;
                    this._multiRange._updateHighlightedRange();
                });
            });
        }
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    _updatePosition(value) {
        let valuePosition = (this._sliderWidth / this._numberOfAvailableValues) * (value - this._multiRange.min);
        if (valuePosition >= this._maxPosition) {
            valuePosition = this._maxPosition;
        }
        if (valuePosition <= this._minPosition) {
            valuePosition = this._minPosition;
        }
        this.coordinates.currentX = valuePosition;
        this.host.style.left = `${this._getOffsetLeft()}px`;
        this._maxPosition = this._getMaxPosition();
        this._minPosition = this._getMinPosition();
    }
    _getMaxPosition() {
        let maxPosition = this._sliderWidth;
        const { nextThumb } = this._getThumbs();
        if (nextThumb) {
            maxPosition = nextThumb.coordinates.currentX;
        }
        return maxPosition;
    }
    _getMinPosition() {
        let minPosition = 0;
        const { previousThumb } = this._getThumbs();
        if (previousThumb) {
            minPosition = previousThumb.coordinates.currentX;
        }
        return minPosition;
    }
    _getOffsetLeft() {
        if (this.coordinates.currentX > this._sliderWidth) {
            return this._sliderWidth;
        }
        if (this.coordinates.currentX <= 0) {
            return 0;
        }
        if (this._multiRange.step > 0) {
            const currentStep = Math.round(this.coordinates.currentX / (this._sliderWidth / this._numberOfAvailableValues)) / this._multiRange.step;
            const stepWidth = this._sliderWidth /
                (this._numberOfAvailableValues / (this._multiRange.step ? this._multiRange.step : 1));
            return stepWidth * currentStep;
        }
        return this.coordinates.currentX;
    }
    _getThumbs() {
        let previousThumb = null;
        let nextThumb = null;
        const thumbs = this._multiRange.rangeThumbs?.toArray();
        if (thumbs?.length > 1) {
            const thumbIndex = this._multiRange.rangeThumbs.toArray().indexOf(this);
            previousThumb = thumbIndex > 0 ? thumbs[thumbIndex - 1] : null;
            nextThumb = thumbIndex < thumbs.length - 1 ? thumbs[thumbIndex + 1] : null;
        }
        return { previousThumb, nextThumb };
    }
    _initDrag() {
        this._ngZone.runOutsideAngular(() => {
            const pointerStart$ = merge(fromEvent(this.host, 'mousedown'), fromEvent(this.host, 'touchstart'));
            const pointerEnd$ = merge(fromEvent(this._document, 'mouseup'), fromEvent(this._document, 'touchend'));
            const pointerDrag$ = merge(fromEvent(this._document, 'mousemove'), fromEvent(this._document, 'touchmove'));
            pointerStart$.pipe(takeUntil(this._destroy$)).subscribe((event) => {
                let clientX = 0;
                if (typeof TouchEvent !== 'undefined' && event instanceof TouchEvent) {
                    clientX = event.touches[0].clientX;
                }
                else if (event instanceof MouseEvent) {
                    clientX = event.clientX;
                }
                this._maxPosition = this._getMaxPosition();
                this._minPosition = this._getMinPosition();
                this.coordinates.initialX = clientX - this.coordinates.currentX;
                this.host.classList.add('thumb-dragging');
                this.showTooltip = true;
                this.startDrag.emit();
                this._cdRef.detectChanges();
                pointerDrag$.pipe(takeUntil(pointerEnd$)).subscribe((event) => {
                    this._ngZone.run(() => {
                        event.preventDefault();
                        this._updatePositionFromEvent(event);
                        this._multiRange._updateHighlightedRange();
                        this.pointerMove.emit();
                    });
                });
                pointerEnd$.pipe(first()).subscribe(() => {
                    this._ngZone.run(() => {
                        this.showTooltip = false;
                        this.host.classList.remove('thumb-dragging');
                        this.changeValue.emit();
                    });
                    this._cdRef.detectChanges();
                });
            });
        });
    }
    _initValues() {
        this._numberOfAvailableValues =
            this._multiRange.max - this._multiRange.min > 0
                ? this._multiRange.max - this._multiRange.min
                : 1;
        this._sliderEl = this.host.parentElement;
        this._sliderWidth = this._sliderEl.offsetWidth - this.THUMB_WIDTH;
        this._maxPosition = this._getMaxPosition();
        this._minPosition = this._getMinPosition();
    }
    _updatePositionFromEvent(event) {
        const clientX = typeof TouchEvent !== 'undefined' && event instanceof TouchEvent
            ? event.touches[0].clientX
            : event.clientX;
        const cursorPosition = clientX - this.coordinates.initialX;
        const stepSize = this._sliderWidth / this._numberOfAvailableValues;
        let isBoundary = false;
        if (cursorPosition < this._minPosition) {
            this.coordinates.currentX = this._minPosition;
            isBoundary = true;
        }
        if (cursorPosition > this._maxPosition) {
            this.coordinates.currentX = this._maxPosition;
            isBoundary = true;
        }
        if (!isBoundary && this._multiRange.step < 1) {
            this.coordinates.currentX = cursorPosition;
        }
        if (this._multiRange.step > 0 &&
            Math.round(cursorPosition / stepSize) % this._multiRange.step != 0) {
            return;
        }
        if (this._multiRange.step > 0 && !isBoundary) {
            this.coordinates.currentX = cursorPosition;
        }
        this.host.style.left = `${this._getOffsetLeft()}px`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeThumbDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: MDB_MULTI_RANGE }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "19.2.1", type: MdbMultiRangeThumbDirective, isStandalone: false, selector: "[mdbMultiRangeThumb]", inputs: { startValue: ["startValue", "startValue", numberAttribute] }, outputs: { startDrag: "startDrag", changeValue: "changeValue", pointerMove: "pointerMove" }, exportAs: ["mdbMultiRangeThumb"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeThumbDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[mdbMultiRangeThumb]',
                    exportAs: 'mdbMultiRangeThumb',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MDB_MULTI_RANGE]
                }] }], propDecorators: { startValue: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], startDrag: [{
                type: Output
            }], changeValue: [{
                type: Output
            }], pointerMove: [{
                type: Output
            }] } });

function fadeInAnimation() {
    return trigger('fadeIn', [
        transition(':enter', [
            useAnimation(animation([
                animate('150ms 0ms', keyframes([
                    style({
                        opacity: 0,
                        transform: 'translateY(20px) scale(0)',
                        offset: 0,
                        easing: 'ease',
                    }),
                    style({
                        opacity: 1,
                        transform: 'translateY(0px) scale(1)',
                        offset: 1,
                        easing: 'ease',
                    }),
                ])),
            ], {
                delay: 0,
            })),
        ]),
        transition(':leave', [
            useAnimation(animation([
                animate('150ms 0ms', keyframes([
                    style({
                        opacity: 0,
                        transform: 'translateY(0px) scale(1)',
                        offset: 0,
                        easing: 'ease',
                    }),
                    style({
                        opacity: 1,
                        transform: 'translateY(0px) scale(0)',
                        offset: 1,
                        easing: 'ease',
                    }),
                ])),
            ], {
                delay: 0,
            })),
        ]),
    ]);
}

class MdbMultiRangeComponent {
    _elRef;
    _cdRef;
    rangeThumbs;
    highlightRange = false;
    max = 100;
    min = 0;
    numberOfRanges = 2;
    tooltip = false;
    get startValues() {
        return this._startValues;
    }
    set startValues(value) {
        this._startValues = value;
        this.val = value;
    }
    _startValues = [0, 100];
    step = 0;
    startDrag = new EventEmitter();
    endDrag = new EventEmitter();
    changeValue = new EventEmitter();
    constructor(_elRef, _cdRef) {
        this._elRef = _elRef;
        this._cdRef = _cdRef;
    }
    get host() {
        return this._elRef.nativeElement;
    }
    _onChange = (_) => { };
    _onTouched = () => { };
    THUMB_WIDTH = 16;
    _destroy$ = new Subject();
    val = [this.startValues[0], this.startValues[1]];
    set value(val) {
        this.val = val;
        this._cdRef.markForCheck();
    }
    highlightedRangeLeft = 0;
    highlightedRangeWidth = 0;
    ngAfterViewInit() {
        setTimeout(() => {
            this._onChange(this._getCurrentValues());
            this.rangeThumbs.forEach((thumb) => {
                fromEvent(thumb.host, 'blur')
                    .pipe(takeUntil(this._destroy$))
                    .subscribe(() => {
                    this._onTouched();
                });
            });
        }, 0);
        merge(...this.rangeThumbs.map((thumb) => thumb.changeValue))
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
            this._onChange(this._getCurrentValues());
            this.value = this._getCurrentValues();
            this.changeValue.emit();
            this.endDrag.emit();
        });
        merge(...this.rangeThumbs.map((thumb) => thumb.startDrag))
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
            this._onChange(this._getCurrentValues());
            this.value = this._getCurrentValues();
            this.startDrag.emit();
        });
        merge(...this.rangeThumbs.map((thumb) => thumb.pointerMove))
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
            if (JSON.stringify(this._getCurrentValues()) === JSON.stringify(this.val)) {
                return;
            }
            this._onChange(this._getCurrentValues());
            this.value = this._getCurrentValues();
        });
        this._updateHighlightedRange();
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    _getCurrentValues() {
        const currentValues = [];
        const numberOfAvailableValues = this.max - this.min > 0 ? this.max - this.min : 1;
        this.rangeThumbs.forEach((thumb, index) => {
            const styleLeft = Number(thumb.host.style.left.split('px')[0]);
            let currentValue = Math.round(styleLeft / ((this.host.offsetWidth - this.THUMB_WIDTH) / numberOfAvailableValues)) + this.min;
            if (currentValue < this.min) {
                currentValue = this.min;
            }
            if (currentValue > this.max) {
                currentValue = this.max;
            }
            currentValues[index] = currentValue;
        });
        return currentValues;
    }
    _updateThumbsPosition(value) {
        const [firstNewValue, secondNewValue] = value;
        const [firstOldValue, secondOldValue] = this.val;
        const rangeThumbs = this.rangeThumbs?.toArray();
        if (firstNewValue !== firstOldValue && rangeThumbs) {
            rangeThumbs[0]._updatePosition(firstNewValue);
        }
        if (secondNewValue !== secondOldValue && rangeThumbs) {
            rangeThumbs[1]._updatePosition(secondNewValue);
        }
    }
    _updateHighlightedRange() {
        if (!this.highlightRange || this.numberOfRanges > 2) {
            return;
        }
        const [firstThumb, secondThumb] = this.rangeThumbs?.toArray();
        const firstThumbLeft = parseInt(firstThumb.host.style.left);
        if (firstThumb && !secondThumb) {
            this.highlightedRangeWidth = firstThumbLeft + this.THUMB_WIDTH;
        }
        if (firstThumb && secondThumb) {
            const secondThumbLeft = parseInt(secondThumb.host.style.left);
            this.highlightedRangeWidth = secondThumbLeft - firstThumbLeft;
            this.highlightedRangeLeft = firstThumbLeft + this.THUMB_WIDTH;
        }
        this._cdRef.markForCheck();
    }
    // Control value accessor methods
    writeValue(value) {
        if (value) {
            this._updateThumbsPosition(value);
            this._updateHighlightedRange();
            this.value = value;
        }
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeComponent, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbMultiRangeComponent, isStandalone: false, selector: "mdb-multi-range", inputs: { highlightRange: ["highlightRange", "highlightRange", booleanAttribute], max: ["max", "max", numberAttribute], min: ["min", "min", numberAttribute], numberOfRanges: ["numberOfRanges", "numberOfRanges", numberAttribute], tooltip: ["tooltip", "tooltip", booleanAttribute], startValues: "startValues", step: ["step", "step", numberAttribute] }, outputs: { startDrag: "startDrag", endDrag: "endDrag", changeValue: "changeValue" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => MdbMultiRangeComponent),
                multi: true,
            },
            { provide: MDB_MULTI_RANGE, useExisting: MdbMultiRangeComponent },
        ], viewQueries: [{ propertyName: "rangeThumbs", predicate: ["rangeThumb"], descendants: true }], ngImport: i0, template: "<div class=\"multi-range-slider\">\n  <div\n    *ngIf=\"highlightRange && numberOfRanges <= 2\"\n    class=\"multi-range-slider-highlighted-range\"\n    [style.width.px]=\"highlightedRangeWidth\"\n    [style.left.px]=\"highlightedRangeLeft\"\n  ></div>\n  <span\n    *ngFor=\"let item of [].constructor(numberOfRanges); let index = index\"\n    mdbMultiRangeThumb\n    [startValue]=\"startValues[index]\"\n    class=\"thumb\"\n    #rangeThumb=\"mdbMultiRangeThumb\"\n    tabindex=\"0\"\n  >\n    <!--  -->\n    <div *ngIf=\"rangeThumb.showTooltip && tooltip\" [@fadeIn]>\n      <ng-container\n        *ngTemplateOutlet=\"tooltipValue; context: { $implicit: val[index] }\"\n      ></ng-container>\n    </div>\n  </span>\n\n  <ng-template #tooltipValue let-value>\n    <div class=\"multi-range-slider-tooltip\">\n      <div class=\"multi-range-slider-tooltip-value\">{{ value }}</div>\n    </div>\n  </ng-template>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: MdbMultiRangeThumbDirective, selector: "[mdbMultiRangeThumb]", inputs: ["startValue"], outputs: ["startDrag", "changeValue", "pointerMove"], exportAs: ["mdbMultiRangeThumb"] }], animations: [fadeInAnimation()], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-multi-range', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => MdbMultiRangeComponent),
                            multi: true,
                        },
                        { provide: MDB_MULTI_RANGE, useExisting: MdbMultiRangeComponent },
                    ], animations: [fadeInAnimation()], changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<div class=\"multi-range-slider\">\n  <div\n    *ngIf=\"highlightRange && numberOfRanges <= 2\"\n    class=\"multi-range-slider-highlighted-range\"\n    [style.width.px]=\"highlightedRangeWidth\"\n    [style.left.px]=\"highlightedRangeLeft\"\n  ></div>\n  <span\n    *ngFor=\"let item of [].constructor(numberOfRanges); let index = index\"\n    mdbMultiRangeThumb\n    [startValue]=\"startValues[index]\"\n    class=\"thumb\"\n    #rangeThumb=\"mdbMultiRangeThumb\"\n    tabindex=\"0\"\n  >\n    <!--  -->\n    <div *ngIf=\"rangeThumb.showTooltip && tooltip\" [@fadeIn]>\n      <ng-container\n        *ngTemplateOutlet=\"tooltipValue; context: { $implicit: val[index] }\"\n      ></ng-container>\n    </div>\n  </span>\n\n  <ng-template #tooltipValue let-value>\n    <div class=\"multi-range-slider-tooltip\">\n      <div class=\"multi-range-slider-tooltip-value\">{{ value }}</div>\n    </div>\n  </ng-template>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { rangeThumbs: [{
                type: ViewChildren,
                args: ['rangeThumb']
            }], highlightRange: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], max: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], min: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], numberOfRanges: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], tooltip: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], startValues: [{
                type: Input
            }], step: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], startDrag: [{
                type: Output
            }], endDrag: [{
                type: Output
            }], changeValue: [{
                type: Output
            }] } });

class MdbMultiRangeModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeModule, declarations: [MdbMultiRangeComponent, MdbMultiRangeThumbDirective], imports: [FormsModule, CommonModule], exports: [MdbMultiRangeComponent, MdbMultiRangeThumbDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeModule, imports: [FormsModule, CommonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbMultiRangeModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MdbMultiRangeComponent, MdbMultiRangeThumbDirective],
                    imports: [FormsModule, CommonModule],
                    exports: [MdbMultiRangeComponent, MdbMultiRangeThumbDirective],
                }]
        }] });

/*
 * Public API Surface of mdb-angular-multi-range
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MdbMultiRangeComponent, MdbMultiRangeModule, MdbMultiRangeThumbDirective };
//# sourceMappingURL=mdb-angular-ui-kit-multi-range.mjs.map
