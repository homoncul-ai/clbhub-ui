import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component, ContentChildren, NgModule } from '@angular/core';
import { Subject, merge } from 'rxjs';
import { startWith, switchMap, takeUntil } from 'rxjs/operators';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class MdbRatingIconComponent {
    _cdRef;
    set icon(value) {
        this._icon = value;
    }
    get icon() {
        return this._icon;
    }
    color = 'primary';
    set active(value) {
        this._active = coerceBooleanProperty(value);
    }
    get active() {
        return this._active;
    }
    set after(value) {
        this._after = value;
    }
    get after() {
        return this._after;
    }
    set before(value) {
        this._before = value;
    }
    get before() {
        return this._before;
    }
    activeIcon = new EventEmitter();
    _active = false;
    _icon = 'fa-star fa-sm';
    _originalIconClass;
    _after = '';
    _before = '';
    disabled = false;
    constructor(_cdRef) {
        this._cdRef = _cdRef;
    }
    onMouseenter() {
        if (this.disabled) {
            return;
        }
        this.setActive(true);
        this.activeIcon.emit(this);
    }
    setActive(isActive, iconClass) {
        this.active = isActive;
        if (iconClass) {
            this.setDynamicIcon(iconClass);
        }
        else {
            this.resetIcon();
        }
        this._cdRef.markForCheck();
    }
    setDynamicIcon(iconClass) {
        if (!this._originalIconClass) {
            this._originalIconClass = this.icon;
        }
        this.icon = iconClass.replace('far', '');
    }
    resetIcon() {
        this.icon = this._originalIconClass || this.icon;
    }
    static ngAcceptInputType_active;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingIconComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbRatingIconComponent, isStandalone: false, selector: "mdb-rating-icon", inputs: { icon: "icon", color: "color", active: "active", after: "after", before: "before" }, outputs: { activeIcon: "activeIcon" }, ngImport: i0, template: "<span>\n  <span class=\"text-body\">{{ before }}</span>\n  <i\n    [ngClass]=\"active ? 'fas ' + icon + ' active' : 'far ' + icon\"\n    [ngStyle]=\"{ color: color }\"\n    (mouseenter)=\"onMouseenter()\"\n  ></i>\n  <span class=\"text-body\">{{ after }}</span>\n</span>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-rating-icon', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<span>\n  <span class=\"text-body\">{{ before }}</span>\n  <i\n    [ngClass]=\"active ? 'fas ' + icon + ' active' : 'far ' + icon\"\n    [ngStyle]=\"{ color: color }\"\n    (mouseenter)=\"onMouseenter()\"\n  ></i>\n  <span class=\"text-body\">{{ after }}</span>\n</span>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { icon: [{
                type: Input
            }], color: [{
                type: Input
            }], active: [{
                type: Input
            }], after: [{
                type: Input
            }], before: [{
                type: Input
            }], activeIcon: [{
                type: Output
            }] } });

class MdbRatingComponent {
    icons;
    readonly = false;
    get value() {
        return this._value;
    }
    set value(newValue) {
        if (newValue !== this.value && typeof newValue === 'number' && !isNaN(newValue)) {
            this._value = newValue < 0 ? 0 : newValue;
        }
        if (this.icons) {
            this.setActive(this.value);
        }
    }
    _value = 0;
    // eslint-disable-next-line @angular-eslint/no-output-on-prefix
    onSelect = new EventEmitter();
    // eslint-disable-next-line @angular-eslint/no-output-on-prefix
    onHover = new EventEmitter();
    _iconIndex;
    _icon;
    _selectedIcon;
    _destroy$ = new Subject();
    constructor() { }
    ngAfterContentInit() {
        this.setActive(this.value);
    }
    ngAfterViewInit() {
        if (this.readonly) {
            this.icons.forEach((icon) => {
                icon.disabled = true;
            });
            return;
        }
        this.icons.changes
            .pipe(startWith(this.icons), switchMap((icons) => {
            return merge(...icons.map((icon) => icon.activeIcon));
        }), takeUntil(this._destroy$))
            .subscribe((icon) => {
            const index = this.icons.toArray().findIndex((el) => {
                return el === icon;
            });
            this._iconIndex = index;
            this._icon = icon.icon;
            this.setActive(index + 1, this._icon);
            this.onHover.emit(this._iconIndex + 1);
        });
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.unsubscribe();
    }
    setActive(iconIndex, iconClass) {
        this.icons.forEach((icon, index) => {
            if (index >= iconIndex) {
                icon.setActive(false);
            }
            else {
                const properIcon = iconClass || (icon.icon ? icon.icon : '');
                icon.setActive(true, properIcon);
            }
        });
    }
    onClick() {
        if (this.readonly) {
            return;
        }
        this.value = this._iconIndex + 1;
        this._selectedIcon = this._icon;
        this.onSelect.emit(this.value);
    }
    onMouseleave() {
        if (this.readonly) {
            return;
        }
        if (this.value) {
            this.setActive(this.value, this._selectedIcon);
        }
        else {
            this.setActive(-1);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbRatingComponent, isStandalone: false, selector: "mdb-rating", inputs: { readonly: "readonly", value: "value" }, outputs: { onSelect: "onSelect", onHover: "onHover" }, queries: [{ propertyName: "icons", predicate: MdbRatingIconComponent }], ngImport: i0, template: "<div class=\"rating\" (click)=\"onClick()\" (mouseleave)=\"onMouseleave()\">\n  <ng-content></ng-content>\n</div>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-rating', standalone: false, template: "<div class=\"rating\" (click)=\"onClick()\" (mouseleave)=\"onMouseleave()\">\n  <ng-content></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { icons: [{
                type: ContentChildren,
                args: [MdbRatingIconComponent]
            }], readonly: [{
                type: Input
            }], value: [{
                type: Input
            }], onSelect: [{
                type: Output
            }], onHover: [{
                type: Output
            }] } });

class MdbRatingModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingModule, declarations: [MdbRatingComponent, MdbRatingIconComponent], imports: [CommonModule], exports: [MdbRatingComponent, MdbRatingIconComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingModule, imports: [CommonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbRatingModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [MdbRatingComponent, MdbRatingIconComponent],
                    imports: [CommonModule],
                    exports: [MdbRatingComponent, MdbRatingIconComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbRatingComponent, MdbRatingIconComponent, MdbRatingModule };
//# sourceMappingURL=mdb-angular-ui-kit-rating.mjs.map
