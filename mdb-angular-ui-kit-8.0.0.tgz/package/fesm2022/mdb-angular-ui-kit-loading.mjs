import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1 from '@angular/cdk/overlay';
import { OverlayConfig, OverlayModule } from '@angular/cdk/overlay';
import { TemplatePortal, PortalModule } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { Input, ViewChild, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';

class MdbLoadingComponent {
    _renderer;
    _overlay;
    _vcr;
    template;
    get show() {
        return this._show;
    }
    set show(value) {
        this._show = coerceBooleanProperty(value);
    }
    _show = false;
    get backdrop() {
        return this._backdrop;
    }
    set backdrop(value) {
        this._backdrop = coerceBooleanProperty(value);
    }
    _backdrop = true;
    backdropClass;
    container;
    get fullscreen() {
        return this._fullscreen;
    }
    set fullscreen(value) {
        this._fullscreen = coerceBooleanProperty(value);
    }
    _fullscreen = false;
    _overlayRef;
    constructor(_renderer, _overlay, _vcr) {
        this._renderer = _renderer;
        this._overlay = _overlay;
        this._vcr = _vcr;
    }
    ngOnInit() {
        if (this.container && !this.fullscreen) {
            this._renderer.addClass(this.container, 'position-relative');
        }
    }
    ngAfterViewInit() {
        if (this.show && this.fullscreen) {
            this.showFullscreen();
        }
    }
    ngOnChanges(changes) {
        if (changes.show &&
            changes.show.currentValue &&
            !changes.show.isFirstChange() &&
            this.fullscreen) {
            this.showFullscreen();
        }
        else if (changes.show &&
            !changes.show.currentValue &&
            !changes.show.isFirstChange() &&
            this.fullscreen) {
            this.hideFullscreen();
        }
    }
    showFullscreen() {
        this._overlayRef = this._createOverlay();
        const templatePortal = new TemplatePortal(this.template, this._vcr);
        this._overlayRef.attach(templatePortal);
    }
    hideFullscreen() {
        this._overlayRef.detach();
    }
    _createOverlay() {
        const config = this._getOverlayConfig();
        return this._overlay.create(config);
    }
    _getOverlayConfig() {
        const config = new OverlayConfig({
            positionStrategy: this._overlay.position().global(),
            scrollStrategy: this._overlay.scrollStrategies.noop(),
            hasBackdrop: this.backdrop,
            backdropClass: this._getBackdropClass(),
        });
        return config;
    }
    _getBackdropClass() {
        const classes = [];
        if (this.backdropClass) {
            this.backdropClass.split(' ').forEach((backdropClass) => {
                classes.push(backdropClass);
            });
        }
        return ['loading-backdrop-fullscreen', ...classes];
    }
    ngOnDestroy() {
        if (this._overlayRef) {
            this._overlayRef.detach();
            this._overlayRef.dispose();
        }
    }
    static ngAcceptInputType_backdrop;
    static ngAcceptInputType_fullscreen;
    static ngAcceptInputType_show;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingComponent, deps: [{ token: i0.Renderer2 }, { token: i1.Overlay }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbLoadingComponent, isStandalone: false, selector: "mdb-loading", inputs: { show: "show", backdrop: "backdrop", backdropClass: "backdropClass", container: "container", fullscreen: "fullscreen" }, viewQueries: [{ propertyName: "template", first: true, predicate: ["template"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<ng-template #template><ng-content></ng-content></ng-template>\n\n<ng-container *ngIf=\"!fullscreen && show\" [ngTemplateOutlet]=\"template\"></ng-container>\n<div *ngIf=\"!fullscreen && show && backdrop\" class=\"loading-backdrop {{ backdropClass }}\"></div>\n", dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-loading', standalone: false, template: "<ng-template #template><ng-content></ng-content></ng-template>\n\n<ng-container *ngIf=\"!fullscreen && show\" [ngTemplateOutlet]=\"template\"></ng-container>\n<div *ngIf=\"!fullscreen && show && backdrop\" class=\"loading-backdrop {{ backdropClass }}\"></div>\n" }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i1.Overlay }, { type: i0.ViewContainerRef }], propDecorators: { template: [{
                type: ViewChild,
                args: ['template']
            }], show: [{
                type: Input
            }], backdrop: [{
                type: Input
            }], backdropClass: [{
                type: Input
            }], container: [{
                type: Input
            }], fullscreen: [{
                type: Input
            }] } });

class MdbLoadingModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingModule, declarations: [MdbLoadingComponent], imports: [CommonModule, OverlayModule, PortalModule], exports: [MdbLoadingComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingModule, imports: [CommonModule, OverlayModule, PortalModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLoadingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OverlayModule, PortalModule],
                    declarations: [MdbLoadingComponent],
                    exports: [MdbLoadingComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbLoadingComponent, MdbLoadingModule };
//# sourceMappingURL=mdb-angular-ui-kit-loading.mjs.map
