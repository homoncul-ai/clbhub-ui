import * as i0 from '@angular/core';
import { Input, HostBinding, Component, EventEmitter, Output, Directive, forwardRef, HostListener, Inject, numberAttribute, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Subject, Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as i2 from 'mdb-angular-ui-kit/select';
import { MdbSelectModule } from 'mdb-angular-ui-kit/select';
import * as i3 from 'mdb-angular-ui-kit/forms';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import * as i4 from 'mdb-angular-ui-kit/option';
import { FormsModule } from '@angular/forms';

// eslint-disable-next-line @angular-eslint/component-class-suffix
class MdbTableDirective {
    el;
    renderer;
    _cdRef;
    get bordered() {
        return this._bordered;
    }
    set bordered(value) {
        this._bordered = coerceBooleanProperty(value);
    }
    _bordered = false;
    get borderless() {
        return this._borderless;
    }
    set borderless(value) {
        this._borderless = coerceBooleanProperty(value);
    }
    _borderless = false;
    get dataSource() {
        return this._dataSource;
    }
    set dataSource(newData) {
        if (newData) {
            this._dataSource = newData;
            Promise.resolve().then(() => {
                this._updateData();
            });
        }
    }
    _dataSource = [];
    get fixedHeader() {
        return this._fixedHeader;
    }
    set fixedHeader(value) {
        this._fixedHeader = coerceBooleanProperty(value);
    }
    _fixedHeader = false;
    filterFn = this.defaultFilterFn;
    get hover() {
        return this._hover;
    }
    set hover(value) {
        this._hover = coerceBooleanProperty(value);
    }
    _hover = false;
    pagination;
    get responsive() {
        return this._responsive;
    }
    set responsive(value) {
        this._responsive = coerceBooleanProperty(value);
    }
    _responsive;
    sort;
    get sm() {
        return this._sm;
    }
    set sm(value) {
        this._sm = coerceBooleanProperty(value);
    }
    _sm = false;
    get striped() {
        return this._striped;
    }
    set striped(value) {
        this._striped = coerceBooleanProperty(value);
    }
    _striped = false;
    constructor(el, renderer, _cdRef) {
        this.el = el;
        this.renderer = renderer;
        this._cdRef = _cdRef;
    }
    _filteredData = [];
    _dataSourceChanged = new Subject();
    _searchText = '';
    data;
    _destroy$ = new Subject();
    addRow(newRow) {
        this._dataSource.push(newRow);
    }
    addRowAfter(index, row) {
        this._dataSource.splice(index, 0, row);
    }
    removeRow(index) {
        this._dataSource.splice(index, 1);
    }
    rowRemoved() {
        return new Observable((observer) => {
            observer.next(true);
        });
    }
    removeLastRow() {
        this._dataSource.pop();
    }
    dataSourceChange() {
        return this._dataSourceChanged;
    }
    ngOnInit() {
        this.renderer.addClass(this.el.nativeElement, 'table');
    }
    ngAfterViewInit() {
        if (this.pagination) {
            this.pagination.paginationChange.pipe(takeUntil(this._destroy$)).subscribe(() => {
                this._updateData();
            });
        }
        if (this.sort) {
            this.sort.sortChange.pipe(takeUntil(this._destroy$)).subscribe(() => {
                this._updateData();
            });
        }
        if (this.fixedHeader) {
            const tableHead = this.el.nativeElement.querySelector('thead');
            Array.from(tableHead.firstElementChild.children).forEach((child) => {
                this.renderer.addClass(child, 'fixed-cell');
            });
        }
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    search(value) {
        this._searchText = value;
        this._updateData();
    }
    _updateData() {
        let updatedData = [];
        updatedData = this._filterData(this.dataSource);
        if (this.sort && this.sort.active) {
            updatedData = this._sortData(updatedData.slice());
        }
        if (this.pagination) {
            updatedData = this._paginateData(updatedData);
        }
        this.data = updatedData;
        this._cdRef.markForCheck();
    }
    _filterData(data) {
        if (this._searchText === null || this._searchText === '') {
            this._filteredData = data;
        }
        else {
            this._filteredData = data.filter((obj) => this.filterFn(obj, this._searchText));
        }
        if (this.pagination) {
            this.pagination.total = this._filteredData.length;
            const currentPage = this.pagination.page;
            if (currentPage > 0) {
                const lastPage = Math.max(Math.ceil(this.pagination.total / this.pagination.entries) - 1, 0);
                if (currentPage > lastPage) {
                    this.pagination.page = lastPage;
                }
            }
        }
        return this._filteredData;
    }
    defaultFilterFn(data, searchTerm) {
        return Object.keys(data).some((key) => {
            if (data[key]) {
                return data[key].toString().toLowerCase().includes(searchTerm.toLowerCase());
            }
        });
    }
    _sortData(data) {
        const name = this.sort.active.name;
        const direction = this.sort.active.direction;
        if (direction !== 'none') {
            return data.sort((a, b) => {
                const result = this._sortFn(a[name], b[name]);
                return direction === 'asc' ? result : -result;
            });
        }
        else {
            return data;
        }
    }
    _sortFn = (a, b) => {
        if (typeof a === typeof b) {
            if (typeof a === 'string' && typeof b === 'string') {
                a = a.toLowerCase();
                b = b.toLowerCase();
            }
            return a < b ? -1 : a > b ? 1 : 0;
        }
        else if (typeof a === 'number') {
            return -1;
        }
        else if (typeof b === 'number') {
            return 1;
        }
    };
    _paginateData(data) {
        const startIndex = this.pagination.page * this.pagination.entries;
        const endIndex = startIndex + this.pagination.entries;
        return data.slice(startIndex, endIndex);
    }
    static ngAcceptInputType_striped;
    static ngAcceptInputType_bordered;
    static ngAcceptInputType_borderless;
    static ngAcceptInputType_hover;
    static ngAcceptInputType_sm;
    static ngAcceptInputType_responsive;
    static ngAcceptInputType_fixedHeader;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbTableDirective, isStandalone: false, selector: "[mdbTable]", inputs: { bordered: "bordered", borderless: "borderless", dataSource: "dataSource", fixedHeader: "fixedHeader", filterFn: "filterFn", hover: "hover", pagination: "pagination", responsive: "responsive", sort: "sort", sm: "sm", striped: "striped" }, host: { properties: { "class.table-bordered": "this.bordered", "class.table-borderless": "this.borderless", "class.table-hover": "this.hover", "class.table-responsive": "this.responsive", "class.table-sm": "this.sm", "class.table-striped": "this.striped" } }, exportAs: ["mdbTable"], ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableDirective, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: '[mdbTable]',
                    exportAs: 'mdbTable',
                    template: '<ng-content></ng-content>',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.ChangeDetectorRef }], propDecorators: { bordered: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-bordered']
            }], borderless: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-borderless']
            }], dataSource: [{
                type: Input
            }], fixedHeader: [{
                type: Input
            }], filterFn: [{
                type: Input
            }], hover: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-hover']
            }], pagination: [{
                type: Input
            }], responsive: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-responsive']
            }], sort: [{
                type: Input
            }], sm: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-sm']
            }], striped: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.table-striped']
            }] } });

class MdbTableSortDirective {
    headers = new Map();
    active;
    sortChange = new EventEmitter();
    sort(header) {
        this.active = header;
        this.headers.forEach((sortHeader) => {
            if (sortHeader.name !== header.name) {
                sortHeader.direction = 'none';
            }
        });
        this.sortChange.emit({ name: header.name, direction: header.direction });
    }
    addHeader(name, header) {
        this.headers.set(name, header);
    }
    removeHeader(name) {
        this.headers.delete(name);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableSortDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbTableSortDirective, isStandalone: false, selector: "[mdbTableSort]", outputs: { sortChange: "sortChange" }, exportAs: ["mdbTableSort"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableSortDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbTableSort]',
                    exportAs: 'mdbTableSort',
                    standalone: false,
                }]
        }], propDecorators: { sortChange: [{
                type: Output
            }] } });

// eslint-disable-next-line @angular-eslint/component-class-suffix
class MdbTableSortHeaderDirective {
    _sort;
    // eslint-disable-next-line @angular-eslint/no-input-rename
    get disableSort() {
        return this._disableSort;
    }
    set disableSort(value) {
        this._disableSort = coerceBooleanProperty(value);
    }
    _disableSort = false;
    get forceSort() {
        return this._forceSort;
    }
    set forceSort(value) {
        this._forceSort = coerceBooleanProperty(value);
    }
    _forceSort = false;
    get name() {
        return this._name;
    }
    set name(value) {
        this._name = this._toCamelCase(value);
    }
    _name;
    direction = 'none';
    get rotate() {
        if (this.direction === 'none' || this.direction === 'asc') {
            return 'rotate(0deg)';
        }
        else {
            return 'rotate(180deg)';
        }
    }
    get cursor() {
        return this.disableSort ? '' : 'pointer';
    }
    onClick() {
        if (this._disableSort) {
            return;
        }
        this.direction = this._getSortingDirection();
        this._sort.sort(this);
    }
    constructor(_sort) {
        this._sort = _sort;
    }
    _toCamelCase(str) {
        return str
            .replace(/\s(.)/g, (a) => {
            return a.toUpperCase();
        })
            .replace(/\s/g, '')
            .replace(/^(.)/, (b) => {
            return b.toLowerCase();
        });
    }
    _getSortingDirection() {
        if (this.forceSort) {
            return this.direction === 'asc' ? 'desc' : 'asc';
        }
        if (this.direction === 'none') {
            return 'asc';
        }
        if (this.direction === 'asc') {
            return 'desc';
        }
        return 'none';
    }
    ngOnInit() {
        this._sort.addHeader(this.name, this);
    }
    ngOnDestroy() {
        this._sort.removeHeader(this.name);
    }
    static ngAcceptInputType_disableSort;
    static ngAcceptInputType_forceSort;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableSortHeaderDirective, deps: [{ token: forwardRef(() => MdbTableSortDirective) }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbTableSortHeaderDirective, isStandalone: false, selector: "[mdbTableSortHeader]", inputs: { disableSort: "disableSort", forceSort: "forceSort", name: ["mdbTableSortHeader", "name"] }, host: { listeners: { "click": "onClick()" }, properties: { "style.cursor": "this.cursor" } }, ngImport: i0, template: "<i\n  *ngIf=\"!disableSort\"\n  class=\"datatable-sort-icon fas fa-arrow-up\"\n  [style.transform]=\"rotate\"\n  [class.active]=\"direction === 'asc' || direction === 'desc'\"\n>\n</i>\n\n<ng-content></ng-content>\n", dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableSortHeaderDirective, decorators: [{
            type: Component,
            args: [{ selector: '[mdbTableSortHeader]', standalone: false, template: "<i\n  *ngIf=\"!disableSort\"\n  class=\"datatable-sort-icon fas fa-arrow-up\"\n  [style.transform]=\"rotate\"\n  [class.active]=\"direction === 'asc' || direction === 'desc'\"\n>\n</i>\n\n<ng-content></ng-content>\n" }]
        }], ctorParameters: () => [{ type: MdbTableSortDirective, decorators: [{
                    type: Inject,
                    args: [forwardRef(() => MdbTableSortDirective)]
                }] }], propDecorators: { disableSort: [{
                type: Input
            }], forceSort: [{
                type: Input
            }], name: [{
                type: Input,
                args: ['mdbTableSortHeader']
            }], cursor: [{
                type: HostBinding,
                args: ['style.cursor']
            }], onClick: [{
                type: HostListener,
                args: ['click']
            }] } });

class MdbTablePaginationComponent {
    allText = 'All';
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    _disabled = false;
    set entries(value) {
        this._entries = value;
        if (this._isInitialized) {
            this._updateEntriesOptions();
        }
    }
    get entries() {
        return this._entries;
    }
    _entries = 10;
    get entriesOptions() {
        return this._entriesOptions;
    }
    set entriesOptions(value) {
        this._entriesOptions = value;
        if (this._isInitialized) {
            this._updateEntriesOptions();
        }
    }
    _entriesOptions = [10, 25, 50, 200];
    get nextButtonDisabled() {
        return this._nextButtonDisabled;
    }
    set nextButtonDisabled(value) {
        this._nextButtonDisabled = coerceBooleanProperty(value);
    }
    _nextButtonDisabled = false;
    ofText = 'of';
    get prevButtonDisabled() {
        return this._prevButtonDisabled;
    }
    set prevButtonDisabled(value) {
        this._prevButtonDisabled = coerceBooleanProperty(value);
    }
    _prevButtonDisabled = false;
    rowsPerPageText = 'Rows per page';
    get showAllEntries() {
        return this._showAllEntries;
    }
    set showAllEntries(value) {
        this._showAllEntries = coerceBooleanProperty(value);
    }
    _showAllEntries = false;
    set total(value) {
        this._total = value;
    }
    get total() {
        return this._total;
    }
    _total = 0;
    get page() {
        return this._page;
    }
    set page(value) {
        this._page = value;
        this.paginationChange.emit({
            page: this.page,
            entries: this.entries,
            total: this.total,
        });
    }
    _page = 0;
    _isInitialized = false;
    firstVisibleItem = 1;
    lastVisibleItem = 0;
    activePageNumber = 1;
    display = 'block';
    paginationChange = new EventEmitter();
    constructor() { }
    ngOnInit() {
        this._isInitialized = true;
        this._updateEntriesOptions();
    }
    getPaginationRangeText() {
        const startIndex = this.page * this.entries;
        const endIndex = Math.min(startIndex + this.entries, this.total);
        return `${this._total ? startIndex + 1 : 0} – ${endIndex} ${this.ofText} ${this.total}`;
    }
    isPreviousPageDisabled() {
        return this.page === 0;
    }
    isNextPageDisabled() {
        const allPages = this._getNumberOfPages();
        return this.page === allPages - 1 || allPages === 0;
    }
    _getNumberOfPages() {
        return Math.ceil(this.total / this.entries);
    }
    nextPage() {
        if (this.isNextPageDisabled()) {
            return;
        }
        this.page++;
    }
    previousPage() {
        if (this.isPreviousPageDisabled()) {
            return;
        }
        this.page--;
    }
    updateRowPerPageNumber(entries) {
        const startIndex = this.page * this.entries;
        if (entries === this.allText) {
            entries = this.total;
        }
        this.entries = entries;
        this.page = Math.floor(startIndex / entries) || 0;
    }
    _updateEntriesOptions() {
        const entriesDefault = 10;
        const hasEntriesOptions = this.entriesOptions.length !== 0;
        const firstOption = hasEntriesOptions && this.entriesOptions[0];
        if (!this.entries) {
            this.entries = firstOption ? firstOption : entriesDefault;
        }
        if (!this.entriesOptions.includes(this.entries) && !this.showAllEntries) {
            this.entriesOptions.push(this.entries);
            this.entriesOptions.sort((a, b) => a - b);
        }
    }
    static ngAcceptInputType_disabled;
    static ngAcceptInputType_prevButtonDisabled;
    static ngAcceptInputType_nextButtonDisabled;
    static ngAcceptInputType_showAllEntries;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTablePaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbTablePaginationComponent, isStandalone: false, selector: "mdb-table-pagination", inputs: { allText: "allText", disabled: "disabled", entries: ["entries", "entries", numberAttribute], entriesOptions: "entriesOptions", nextButtonDisabled: "nextButtonDisabled", ofText: "ofText", prevButtonDisabled: "prevButtonDisabled", rowsPerPageText: "rowsPerPageText", showAllEntries: "showAllEntries", total: "total", page: "page" }, outputs: { paginationChange: "paginationChange" }, host: { properties: { "style.display": "this.display" } }, exportAs: ["mdbPagination"], ngImport: i0, template: "<div class=\"datatable-pagination\">\n  <div class=\"datatable-select-wrapper\">\n    <p class=\"datatable-select-text\">{{ rowsPerPageText }}:</p>\n    <mdb-form-control>\n      <mdb-select\n        [value]=\"showAllEntries ? (entries === total ? allText : entries) : entries\"\n        (selected)=\"updateRowPerPageNumber($event)\"\n        [disabled]=\"disabled\"\n      >\n        <mdb-option *ngFor=\"let entry of entriesOptions\" [value]=\"entry\">{{ entry }}</mdb-option>\n        <mdb-option *ngIf=\"showAllEntries\" [value]=\"allText\">{{ allText }}</mdb-option>\n      </mdb-select>\n    </mdb-form-control>\n  </div>\n  <div class=\"datatable-pagination-nav\">{{ getPaginationRangeText() }}</div>\n\n  <div class=\"datatable-pagination-buttons\">\n    <button\n      type=\"button\"\n      class=\"btn btn-link datatable-pagination-button datatable-pagination-left\"\n      [ngClass]=\"{ disabled: disabled || isPreviousPageDisabled() || prevButtonDisabled }\"\n      [disabled]=\"disabled || isPreviousPageDisabled() || prevButtonDisabled\"\n      (click)=\"previousPage()\"\n    >\n      <i class=\"fa fa-chevron-left\"></i>\n    </button>\n\n    <button\n      type=\"button\"\n      class=\"btn btn-link datatable-pagination-button datatable-pagination-right\"\n      [ngClass]=\"{ disabled: disabled || isNextPageDisabled() || nextButtonDisabled }\"\n      [disabled]=\"disabled || isNextPageDisabled() || nextButtonDisabled\"\n      (click)=\"nextPage()\"\n    >\n      <i class=\"fa fa-chevron-right\"></i>\n    </button>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MdbSelectComponent, selector: "mdb-select", inputs: ["autoSelect", "clearButton", "clearButtonTabindex", "disabled", "dropdownClass", "displayedLabels", "highlightFirst", "multiple", "notFoundMsg", "optionsSelectedLabel", "placeholder", "tabindex", "required", "filter", "filterFn", "filterPlaceholder", "filterDebounce", "aria-label", "aria-labelledby", "visibleOptions", "optionHeight", "dropdownHeight", "value", "compareWith", "sortComparator", "size", "inputId", "inputFilterId"], outputs: ["valueChange", "opened", "closed", "search", "selected", "deselected"] }, { kind: "component", type: i3.MdbFormControlComponent, selector: "mdb-form-control" }, { kind: "component", type: i4.MdbOptionComponent, selector: "mdb-option", inputs: ["value", "label", "disabled"], outputs: ["selectionChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTablePaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-table-pagination', exportAs: 'mdbPagination', standalone: false, template: "<div class=\"datatable-pagination\">\n  <div class=\"datatable-select-wrapper\">\n    <p class=\"datatable-select-text\">{{ rowsPerPageText }}:</p>\n    <mdb-form-control>\n      <mdb-select\n        [value]=\"showAllEntries ? (entries === total ? allText : entries) : entries\"\n        (selected)=\"updateRowPerPageNumber($event)\"\n        [disabled]=\"disabled\"\n      >\n        <mdb-option *ngFor=\"let entry of entriesOptions\" [value]=\"entry\">{{ entry }}</mdb-option>\n        <mdb-option *ngIf=\"showAllEntries\" [value]=\"allText\">{{ allText }}</mdb-option>\n      </mdb-select>\n    </mdb-form-control>\n  </div>\n  <div class=\"datatable-pagination-nav\">{{ getPaginationRangeText() }}</div>\n\n  <div class=\"datatable-pagination-buttons\">\n    <button\n      type=\"button\"\n      class=\"btn btn-link datatable-pagination-button datatable-pagination-left\"\n      [ngClass]=\"{ disabled: disabled || isPreviousPageDisabled() || prevButtonDisabled }\"\n      [disabled]=\"disabled || isPreviousPageDisabled() || prevButtonDisabled\"\n      (click)=\"previousPage()\"\n    >\n      <i class=\"fa fa-chevron-left\"></i>\n    </button>\n\n    <button\n      type=\"button\"\n      class=\"btn btn-link datatable-pagination-button datatable-pagination-right\"\n      [ngClass]=\"{ disabled: disabled || isNextPageDisabled() || nextButtonDisabled }\"\n      [disabled]=\"disabled || isNextPageDisabled() || nextButtonDisabled\"\n      (click)=\"nextPage()\"\n    >\n      <i class=\"fa fa-chevron-right\"></i>\n    </button>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { allText: [{
                type: Input
            }], disabled: [{
                type: Input
            }], entries: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], entriesOptions: [{
                type: Input
            }], nextButtonDisabled: [{
                type: Input
            }], ofText: [{
                type: Input
            }], prevButtonDisabled: [{
                type: Input
            }], rowsPerPageText: [{
                type: Input
            }], showAllEntries: [{
                type: Input
            }], total: [{
                type: Input
            }], page: [{
                type: Input
            }], display: [{
                type: HostBinding,
                args: ['style.display']
            }], paginationChange: [{
                type: Output
            }] } });

class MdbTableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbTableModule, declarations: [MdbTablePaginationComponent,
            MdbTableSortDirective,
            MdbTableSortHeaderDirective,
            MdbTableDirective], imports: [CommonModule, MdbSelectModule, MdbFormsModule, FormsModule], exports: [MdbTablePaginationComponent,
            MdbTableSortDirective,
            MdbTableSortHeaderDirective,
            MdbTableDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableModule, imports: [CommonModule, MdbSelectModule, MdbFormsModule, FormsModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MdbSelectModule, MdbFormsModule, FormsModule],
                    declarations: [
                        MdbTablePaginationComponent,
                        MdbTableSortDirective,
                        MdbTableSortHeaderDirective,
                        MdbTableDirective,
                    ],
                    exports: [
                        MdbTablePaginationComponent,
                        MdbTableSortDirective,
                        MdbTableSortHeaderDirective,
                        MdbTableDirective,
                    ],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbTableDirective, MdbTableModule, MdbTablePaginationComponent, MdbTableSortDirective, MdbTableSortHeaderDirective };
//# sourceMappingURL=mdb-angular-ui-kit-table.mjs.map
