import { InjectionToken, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare const MDB_STEP_HEADER: InjectionToken<MdbStepHeaderDirective>;
export declare class MdbStepHeaderDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbStepHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbStepHeaderDirective, "[mdbStepHeader]", never, {}, {}, never, never, false, never>;
}
