import * as i0 from "@angular/core";
import * as i1 from "./stepper.component";
import * as i2 from "./step.component";
import * as i3 from "./step-icon.directive";
import * as i4 from "./step-header.directive";
import * as i5 from "@angular/common";
import * as i6 from "@angular/cdk/portal";
export declare class MdbStepperModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbStepperModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbStepperModule, [typeof i1.MdbStepperComponent, typeof i2.MdbStepComponent, typeof i3.MdbStepIconDirective, typeof i4.MdbStepHeaderDirective], [typeof i5.CommonModule, typeof i6.PortalModule], [typeof i1.MdbStepperComponent, typeof i2.MdbStepComponent, typeof i3.MdbStepIconDirective, typeof i4.MdbStepHeaderDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbStepperModule>;
}
