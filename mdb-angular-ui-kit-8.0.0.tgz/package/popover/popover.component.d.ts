import { ChangeDetectorRef, TemplateRef } from '@angular/core';
import { AnimationEvent } from '@angular/animations';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class MdbPopoverComponent {
    private _cdRef;
    animation: boolean;
    content: string | TemplateRef<any>;
    context: any;
    title: string;
    get isContentTemplate(): boolean;
    readonly _hidden: Subject<void>;
    animationState: string;
    constructor(_cdRef: ChangeDetectorRef);
    markForCheck(): void;
    onAnimationEnd(event: AnimationEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbPopoverComponent, "mdb-popover", never, { "animation": { "alias": "animation"; "required": false; }; "content": { "alias": "content"; "required": false; }; "context": { "alias": "context"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, false, never>;
    static ngAcceptInputType_animation: unknown;
}
