import { ElementRef, EventEmitter, AfterViewInit } from '@angular/core';
import { MdbTimepickerComponent } from './timepicker.component';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare const MDB_TIMEPICKER_VALUE_ACCESSOR: any;
export declare class MdbTimepickerDirective implements ControlValueAccessor, AfterViewInit {
    private el;
    onChange: (value: any) => void;
    onTouched: () => void;
    disabled: boolean;
    mdbTimepicker: MdbTimepickerComponent;
    get value(): string;
    set value(value: string);
    private _value;
    _valueChange: EventEmitter<string>;
    constructor(el: ElementRef);
    handleInput(event: any): void;
    ngAfterViewInit(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTimepickerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTimepickerDirective, "[mdbTimepicker]", never, { "disabled": { "alias": "disabled"; "required": false; }; "mdbTimepicker": { "alias": "mdbTimepicker"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
    static ngAcceptInputType_disabled: unknown;
}
